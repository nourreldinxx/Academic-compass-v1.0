package calculator;

public class Calculator {

    public static void main(String[] args) {
          login l = new login();
            l.setVisible(true);

    }

}
